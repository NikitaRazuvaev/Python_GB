import tkinter as tk
from tkinter import *

frm = []; btn = []; who = True
playArea = []
standings = []   

class Games:
    def new_window(self):
        self.newWindow = tk.Toplevel(self.master)
        self.app = window_win(self.newWindow)

    def __init__(self,master):
        self.master = master
        self.frame = tk.Frame(self.master)
        self.frame.pack()
    def play(n, master, self):
        
        global who
        Games.btn[n].config(text= 'X' if who else 'O', state=DISABLED)
        Games.playArea[n] = 1 if who else -1
        Games.standings[0] = Games.playArea[0] + Games.playArea[1] + Games.playArea[2]
        Games.standings[1] = Games.playArea[3] + Games.playArea[4] + Games.playArea[5]
        Games.standings[2] = Games.playArea[6] + Games.playArea[7] + Games.playArea[8]
        Games.standings[4] = Games.playArea[1] + Games.playArea[4] + Games.playArea[7]
        Games.standings[5] = Games.playArea[2] + Games.playArea[5] + Games.playArea[8]
        Games.standings[3] = Games.playArea[0] + Games.playArea[3] + Games.playArea[6]
        Games.standings[6] = Games.playArea[0] + Games.playArea[4] + Games.playArea[8]
        Games.standings[7] = Games.playArea[2] + Games.playArea[4] + Games.playArea[6]
        
        print(n, Games.standings[0:8])
        for i in range(8):
            if Games.standings[i] == 3:
                win = str('X')
                print('X win')
                return win
            elif Games.standings[i] == -3:
                win = str('O')
                print('O win')
                return win
        who = not(who)
    for i in range(3):
        frm.append(Frame())
        frm[i].pack(expand=YES, fill=BOTH)
        for j in range(3):
            btn.append(Button(frm[i], text=' ', font=('mono', 20, 'bold'), width=3, height=2))
            btn[i*3+j].config(command=lambda n=i*3+j:Games.play(n))
            btn[i*3+j].pack(expand=YES, fill=BOTH, side=LEFT, padx=1, pady=1)
            playArea.append(0)
            standings.append(0)
class window_win:
    def __init__(self, master):
        self.master = master
        label = tk.Label(text=f"Win {win}!")
        self.quitButton = tk.Button(self.frame, text = 'Quit', width = 25, command = self.close_windows)
        self.frame = tk.Frame(self.master)
        self.frame.pack()
    def close_windows(self):
        self.master.destroy()

def main(): 
    window = tk.Tk()
    window.title("Игра Крестики-нолики")
    app = Games(window)
    window.mainloop()

if __name__ == '__main__':
    main()