
import random, time

window =Tk()

label= Label(width=20, text='Игра Крестики-нолики', font=('Arial',20, 'bold'))
window.title("Игра Крестики-нолики")
buttons = Button(window,[Button(width=5, height=2,font=('Arial',20, 'bold'), bg='blue') for i in range(9)])
row=1; col = 0
for i in range(9):
    buttons[i].grid(row=row,column=col)
    col+=1
    if col ==3:
        row+=1
        col=0



label.grid(row=0,column=0,columnspan=3)
row=1; col = 0




